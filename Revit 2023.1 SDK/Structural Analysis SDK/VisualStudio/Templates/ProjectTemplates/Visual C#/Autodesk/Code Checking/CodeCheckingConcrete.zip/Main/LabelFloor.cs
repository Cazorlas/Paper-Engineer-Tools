﻿//
// (C) Copyright 2003-2013 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.DB;
using $safeprojectname$.ConcreteTypes;
using CT = $safeprojectname$.ConcreteTypes;
using Autodesk.Revit.DB.CodeChecking.Engineering.Concrete.ConcreteTypes;
using Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes;
using Autodesk.Revit.UI.ExtensibleStorage.Framework;

/// <structural_toolkit_2015>
namespace $safeprojectname$.Main
{
   /// <summary>
   /// Values validator for beam label.
   /// </summary>
   public class ValueValidatorFloor : IFieldValidator
   {
      /// <summary>
      /// Validates the value.
      /// </summary>
      /// <param name="entity">The entity.</param>
      /// <param name="field">The field.</param>
      /// <param name="value">The value.</param>
      /// <param name="unit">The unit.</param>
      /// <returns>Information about data validation.</returns>
      public bool ValidateValue(object entity, string field, object value, DisplayUnitType unit)
      {
         ///<WIZARD OPTION="$RC_CREEP">
         if (field == "CreepCoefficient")
         {
            return (double)value > 0;
         }
         ///</WIZARD>
         return true;
      }
   }
   /// <summary>
   /// Container for RC floor and slab foundation elements material and calculation options
   /// </summary>
   [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.Schema("LabelFloor","$guid18$")]
   public class LabelFloor : Autodesk.Revit.DB.ExtensibleStorage.Framework.SchemaClass
   {
      ///<WIZARD OPTION="$RC_TEMPLATE_ONLY">
      /// <summary>
      /// Collection of simple calculation type objects
      /// representing calculation options chosen by the user
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "FloorCalculationType")]
      [EnumControl(Description = "EnabledInternalForces", Category = "CalculationOptions", EnumType = typeof(ConcreteTypes.EnabledInternalForces), Presentation = PresentationMode.OptionList, Item = PresentationItem.ImageWithText, ImageSize = ImageSize.Medium, Context = "FloorLabel")]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ListValue(Name = "EnabledInternalForces", Index = 1, Localizable=true, LocalizableValue = true)]
      public List<ConcreteTypes.EnabledInternalForces> EnabledInternalForces { get; set; }
      ///</WIZARD>
      /// <summary>
      /// Rebar parameters component for primary reinforcement
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "PrimaryRnfSteelParameters")]
      [$safeprojectname$.UIComponents.RCSteelParameters.RCSteelParameters(Category = "PrimaryRnfSteelParameters")]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ValueWithName(LocalizableValue = true, Name = "PrimaryRnfSteelParameters", Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public $safeprojectname$.UIComponents.RCSteelParameters.RCSteelParametersSchema PrimaryReinforcement { get; set; }

      /// <summary>
      /// Rebar parameters component for secondary reinforcement
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "SecondaryRnfSteelParameters")]
      [$safeprojectname$.UIComponents.RCSteelParameters.RCSteelParameters(Category = "SecondaryRnfSteelParameters")]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ValueWithName(LocalizableValue = true, Name = "SecondaryRnfSteelParameters", Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public $safeprojectname$.UIComponents.RCSteelParameters.RCSteelParametersSchema SecondaryReinforcement { get; set; }
      ///<WIZARD OPTION="$RC_CREEP">
      /// <summary>
      /// Creep coefficient
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "CreepCoefficient", Unit = Autodesk.Revit.DB.UnitType.UT_Number, DisplayUnit = Autodesk.Revit.DB.DisplayUnitType.DUT_GENERAL)]
      [Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.TextBox(Description = "CreepCoefficient", Category = "CalculationOptions", IsVisible = true, IsEnabled = true, Index = -1, Localizable = true, FieldValidator = typeof(ValueValidatorFloor))]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ValueWithName(LocalizableValue = true, Name = "CreepCoefficient", Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public Double CreepCoefficient { get; set; }
      ///</WIZARD>
      /// <summary>
      /// Creates default LabelFloor
      /// </summary>
      public LabelFloor()
      {
         PrimaryReinforcement = new $safeprojectname$.UIComponents.RCSteelParameters.RCSteelParametersSchema();
         SecondaryReinforcement = new $safeprojectname$.UIComponents.RCSteelParameters.RCSteelParametersSchema();
         ///<WIZARD OPTION="$RC_CREEP">
         CreepCoefficient = 2.0;
         ///</WIZARD>
         ///<WIZARD OPTION="$RC_TEMPLATE_ONLY">
         EnabledInternalForces = new List<ConcreteTypes.EnabledInternalForces>();
         EnabledInternalForces.Add(ConcreteTypes.EnabledInternalForces.MY);
        ///</WIZARD>
      }
   }
}
/// </structural_toolkit_2015>
