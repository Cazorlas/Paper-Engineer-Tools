﻿using System.Collections.Generic;

namespace $safeprojectname$
{
   namespace ConcreteTypes // todo: move this class to a new project file
   {
      /// <summary>
      /// Classification of available forces
      /// </summary>
      public enum EnabledInternalForces
      {
         /// <summary>
         /// Axial force. The force acting along the element.
         /// </summary>
         FX = 0x01,
         /// <summary>
         /// Shear force. The force acting perpendicular to the element, along Y axia.
         /// </summary>
         FY = 0x02,
         /// <summary>
         /// Shear force. The force acting perpendicular to the element along Z axis.
         /// </summary>
         FZ = 0x04,
         /// <summary>
         /// Torsional moment.
         /// </summary>
         MX = 0x08,
         /// <summary>
         /// Bending moment. Bending around the Y axis.
         /// </summary>
         MY = 0x10,
         /// <summary>
         /// Bending moment. Bending around the Z axis.
         /// </summary>
         MZ = 0x20,
      }
      /// <structural_toolkit_2015>
  
      /// <summary>
      /// Classification of forces direction in the plain object
      /// </summary>
      public enum DimensioningDirection
      {
         /// <summary>
         /// Main dirction.
         /// </summary>
         X,
         /// <summary>
         /// Secondary direction, ortogonal to main.
         /// </summary>
         Y
      }

      /// </structural_toolkit_2015>


      /// <summary>
      /// Type of beam section
      /// </summary>
      public enum BeamSectionType 
      { 
         /// <summary>
         /// Section with slab interaction
         /// </summary>
         WithSlabBeamInteraction, 
         /// <summary>
         /// Section without slab interaction
         /// </summary>
         WithoutSlabBeamInteraction
      }

      /// <summary>
      /// Type of column structure type
      /// </summary>
      public enum ColumnStructureType
      {
         /// <summary>
         /// Sway structure 
         /// </summary>
         Sway,
         /// <summary>
         /// Non-sway structure
         /// </summary>
         NonSway
      }

      /// <summary>
      /// Converter class 
      /// </summary>
      public static class CalculationTypeHelper
      {

          /// <structural_toolkit_2015>
 
         /// <summary>
         ///  Convertion into ForceType
         /// </summary>
         /// <param name="enabledForce">EnabledForce to be converted</param>
         /// <param name="category">Type of element as BuiltInCategory</param>
         /// <returns>Forces type as ForceType</returns>
         public static Autodesk.Revit.DB.CodeChecking.Engineering.ForceType GetForceType(this EnabledInternalForces enabledForce, Autodesk.Revit.DB.BuiltInCategory category = Autodesk.Revit.DB.BuiltInCategory.OST_BeamAnalytical )
         {
            switch( category )
            {
               case Autodesk.Revit.DB.BuiltInCategory.OST_BeamAnalytical:
               case Autodesk.Revit.DB.BuiltInCategory.OST_ColumnAnalytical:
                  {

                     switch (enabledForce)
                     {
                        default: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Unknown;
                        case EnabledInternalForces.FX: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Fx;
                        case EnabledInternalForces.FY: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Fy;
                        case EnabledInternalForces.FZ: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Fz;
                        case EnabledInternalForces.MX: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Mx;
                        case EnabledInternalForces.MY: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.My;
                        case EnabledInternalForces.MZ: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Mz;
                     }
                  }
               case Autodesk.Revit.DB.BuiltInCategory.OST_FloorAnalytical:
               case Autodesk.Revit.DB.BuiltInCategory.OST_FoundationSlabAnalytical:
               case Autodesk.Revit.DB.BuiltInCategory.OST_WallAnalytical:
                  {

                     switch (enabledForce)
                     {
                        default: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Unknown;
                        case EnabledInternalForces.FX: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Fxx;
                        case EnabledInternalForces.FY: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Fyy;
                        case EnabledInternalForces.MX: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Mxx;
                        case EnabledInternalForces.MY: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Myy;
                     }
                  }
               default: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Unknown;
            }
         }
         /// </structural_toolkit_2015>

      }
   }
}
