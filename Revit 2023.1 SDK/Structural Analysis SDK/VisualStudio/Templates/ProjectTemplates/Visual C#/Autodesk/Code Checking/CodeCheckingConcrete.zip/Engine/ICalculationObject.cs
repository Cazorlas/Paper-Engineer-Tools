﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$.Engine
{
   /// <summary>
   /// Represents type of a calculation object.
   /// </summary>
   public enum CalculationObjectType
   {
      /// <summary>
      /// Designed for elements objects.
      /// </summary>
      Element,
      /// <summary>
      /// Designed for sections objects.
      /// </summary>
      Section,
   }

   /// <summary>
   /// Represents type of a calculation object.
   /// </summary>
   public enum ErrorResponse
   {
      /// <summary>
      /// Execute the Run method when "false" value was returned in previus Run methods.
      /// </summary>
      RunOnError,
      /// <summary>
      /// Skip the Run method when "false" value was returned in previus Run methods.
      /// </summary>
      SkipOnError,
   }

   /// <summary>
   /// Base interface for calculation objects.
   /// </summary>
   public interface ICalculationObject
   {
      /// <summary>
      /// Runs calculation\operations for an element cref="ElementDataBase" object or for a section object cref="SectionDataBase".
      /// </summary>
      /// <param name="obj">An element object or a section object</param>
      /// <returns>Result of calculation.</returns>
      bool Run(ObjectDataBase obj);
      /// <summary>
      /// Sets and gets common parameters.
      /// </summary>
      CommonParametersBase Parameters { get; set; }
      /// <summary>
      /// Gets and sets type of the calculation object.
      /// </summary>
      CalculationObjectType Type { get; set; }
      /// <summary>
      /// Gets and sets a type of error response of the calculation object.
      /// </summary>
      ErrorResponse ErrorResponse  { get; set; }
      /// <summary>
      /// Gets and sets categories for the calculation object.
      /// </summary>
      IList<Autodesk.Revit.DB.BuiltInCategory> Categories { get; set; }
   }
}
