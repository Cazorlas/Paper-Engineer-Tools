﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.DB;
using $safeprojectname$.ConcreteTypes;
using Autodesk.Revit.DB.ExtensibleStorage.Framework;
using Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes;
using Autodesk.Revit.UI.ExtensibleStorage.Framework;

namespace $safeprojectname$.Main
{
   /// <summary>
   /// Values validator for column label.
   /// </summary>
   public class ValueValidatorColumn : IFieldValidator
   {
      /// <summary>
      /// Validates the value.
      /// </summary>
      /// <param name="entity">The entity.</param>
      /// <param name="field">The field.</param>
      /// <param name="value">The value.</param>
      /// <param name="unit">The unit.</param>
      /// <returns></returns>
      public bool ValidateValue(object entity, string field, object value, DisplayUnitType unit)
      {
         ///<WIZARD OPTION="$RC_CREEP">
         if (field == "CreepCoefficient")
         {
            return (double)value > 0;
         }
         ///</WIZARD>
         
         if (field == "LengthCoefficientY" || field == "LengthCoefficientZ")
         {
            return (double)value >= 0;
         }
         
         return true;
      }
   }
      
   /// <summary>
   /// Container for RC column element material and calculation options
   /// </summary>
   [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.Schema("LabelColumn", "$guid10$")]
   [Categories(new string[] { 
      "CalculationOptions", 
      ///<WIZARD OPTION="$RC_COLUMN_BUCKLING">
      "Buckling", 
      ///</WIZARD>
      "LongitudinalReinforcement", 
      "TransversalReinforcement" }, 
      new int[] { 1, 2, 3, 4 })]
   public class LabelColumn : Autodesk.Revit.DB.ExtensibleStorage.Framework.SchemaClass
   {
       ///<WIZARD OPTION="$RC_TEMPLATE_ONLY">
      /// <summary>
      /// Collection of simple calculation type objects
      /// representing calculation options chosen by the user
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "ColumnCalculationType")]
      [EnumControl(Description = "EnabledInternalForces", Category = "CalculationOptions", EnumType = typeof(ConcreteTypes.EnabledInternalForces), Presentation = PresentationMode.OptionList, Item = PresentationItem.ImageWithText, ImageSize = ImageSize.Medium, Context = "ColumnLabel")]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ListValue(Name = "EnabledInternalForces", Index = 1, Localizable=true, LocalizableValue = true)]
      public List<ConcreteTypes.EnabledInternalForces> EnabledInternalForces { get; set; }
      ///</WIZARD>
      ///<WIZARD OPTION="$RC_CREEP">
      /// <summary>
      /// Creep coefficient
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "CreepCoefficient", Unit = Autodesk.Revit.DB.UnitType.UT_Number, DisplayUnit = Autodesk.Revit.DB.DisplayUnitType.DUT_GENERAL)]
      [Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.TextBox(Description = "CreepCoefficient", Category = "CalculationOptions", IsVisible = true, IsEnabled = true, Index = -1, Localizable = true, FieldValidator = typeof(ValueValidatorColumn))]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ValueWithName(LocalizableValue = true, Name = "CreepCoefficient", Index = 2, Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public Double CreepCoefficient { get; set; }
      ///</WIZARD>

      ///<WIZARD OPTION="$RC_COLUMN_BUCKLING">
      /// <summary>
      /// Take into account buckling on direction Y when calculating element
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "BucklingDirectionY")]
      [Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.CheckBox(Category = "Buckling", Description = "BucklingDirectionY", IsVisible = true, IsEnabled = true, Index = 2, Localizable = true)]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ValueWithName(LocalizableValue = true, Name = "BucklingDirectionY", Index = 3, Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public bool BucklingDirectionY { get; set; }

      /// <summary>
      /// Value of the buckling coefficietn on direction Y
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "LengthCoefficientY", Unit = Autodesk.Revit.DB.UnitType.UT_Number, DisplayUnit = Autodesk.Revit.DB.DisplayUnitType.DUT_GENERAL)]
      [Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.TextBox(Category = "Buckling", Description = "LengthCoefficientY", IsVisible = true, IsEnabled = true, Index = 3, Localizable = true)]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ValueWithName(LocalizableValue = true, Name = "LengthCoefficientY", Index = 4, Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public Double LengthCoefficientY { get; set; }


      /// <summary>
      /// Structure type on direction Y: Sway or No-sway
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "ColumnStructureTypeY")]
      [Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.EnumControl(EnumType = typeof(ConcreteTypes.ColumnStructureType), Presentation = Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.PresentationMode.Combobox, Item = Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.PresentationItem.Text, Category = "Buckling", Description = "ColumnStructureType", IsVisible = true, IsEnabled = true, Index = 4, Localizable = true)]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ValueWithName(LocalizableValue = true, Name = "ColumnStructureType", Index = 5, Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public ConcreteTypes.ColumnStructureType ColumnStructureTypeY { get; set; }

      /// <summary>
      /// Take into account buckling on direction Z when calculating element
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "BucklingDirectionZ")]
      [Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.CheckBox(Category = "Buckling", Description = "BucklingDirectionZ", IsVisible = true, IsEnabled = true, Index = 5, Localizable = true)]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ValueWithName(LocalizableValue = true, Name = "BucklingDirectionZ", Index = 6, Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public bool BucklingDirectionZ { get; set; }

      /// <summary>
      /// Value of the buckling coefficietn on direction Z
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "LengthCoefficientZ", Unit = Autodesk.Revit.DB.UnitType.UT_Number, DisplayUnit = Autodesk.Revit.DB.DisplayUnitType.DUT_GENERAL)]
      [Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.TextBox(Category = "Buckling", Description = "LengthCoefficientZ", IsVisible = true, IsEnabled = true, Index = 6, Localizable = true)]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ValueWithName(LocalizableValue = true, Name = "LengthCoefficientZ", Index = 7, Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public Double LengthCoefficientZ { get; set; }

      /// <summary>
      /// Structure type on direction Z: Sway or No-sway
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "ColumnStructureTypeZ")]
      [Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.EnumControl(EnumType = typeof(ConcreteTypes.ColumnStructureType), Presentation = Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.PresentationMode.Combobox, Item = Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.PresentationItem.Text, Category = "Buckling", Description = "ColumnStructureType", IsVisible = true, IsEnabled = true, Index = 7, Localizable = true)]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ValueWithName(LocalizableValue = true, Name = "ColumnStructureType", Index = 8, Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public ConcreteTypes.ColumnStructureType ColumnStructureTypeZ { get; set; }
      ///</WIZARD>

      /// <summary>
      /// Rebar parameters component for longitudinal reinforcement
      ///</summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "LongitudinalReinforcement")]
      [$safeprojectname$.UIComponents.RCSteelParameters.RCSteelParameters(Category = "LongitudinalReinforcement")]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.SubSchemaElement(LocalizableValue = true, Name = "LongitudinalReinforcement", Index = 9, Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public $safeprojectname$.UIComponents.RCSteelParameters.RCSteelParametersSchema LongitudinalReinforcement { get; set; }

      /// <summary>
      /// Rebar parameters component for transversal reinforcement
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "TransversalReinforcement")]
      [$safeprojectname$.UIComponents.RCSteelParameters.RCSteelParameters(Category = "TransversalReinforcement")]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.SubSchemaElement(LocalizableValue = true, Name = "TransversalReinforcement", Index = 10, Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public $safeprojectname$.UIComponents.RCSteelParameters.RCSteelParametersSchema TransversalReinforcement { get; set; }

      /// <summary>
      /// Creates default LabelColumn
      /// </summary>
      public LabelColumn()
      {
         LongitudinalReinforcement = new $safeprojectname$.UIComponents.RCSteelParameters.RCSteelParametersSchema();
		   ///<WIZARD OPTION="$RC_CREEP">
         CreepCoefficient = 2.0;
		   ///</WIZARD>
         TransversalReinforcement = new $safeprojectname$.UIComponents.RCSteelParameters.RCSteelParametersSchema();
         ///<WIZARD OPTION="$RC_TEMPLATE_ONLY">
         EnabledInternalForces = new List<ConcreteTypes.EnabledInternalForces>();
         EnabledInternalForces.Add(ConcreteTypes.EnabledInternalForces.MY);
         EnabledInternalForces.Add(ConcreteTypes.EnabledInternalForces.FX);
         ///</WIZARD>
         ///<WIZARD OPTION="$RC_COLUMN_BUCKLING">
         LengthCoefficientY = 1.0;
         LengthCoefficientZ = 1.0;
         BucklingDirectionY = true;
         BucklingDirectionZ = true;
         ColumnStructureTypeY=ConcreteTypes.ColumnStructureType.NonSway;
         ColumnStructureTypeZ = ConcreteTypes.ColumnStructureType.NonSway;
         ///</WIZARD>
      }

   }
}
