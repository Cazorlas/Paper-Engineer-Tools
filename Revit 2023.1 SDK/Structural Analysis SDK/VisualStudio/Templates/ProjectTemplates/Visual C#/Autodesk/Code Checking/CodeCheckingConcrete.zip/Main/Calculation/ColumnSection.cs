﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.CodeChecking.Engineering;
using Autodesk.CodeChecking.Concrete;
using $safeprojectname$.Engine;
using $safeprojectname$.Concrete;
using $safeprojectname$.Utility;

namespace $safeprojectname$.Main.Calculation
{
   /// <summary>
   /// Represents user's section of a column element.
   /// </summary>
   class ColumnSection : LinearSection
   {
      /// <summary>
      /// Initializes a new instance of user's section object of column element.  
      /// </summary>
      /// <param name="sectionDataBase">Instance of base section object with predefined parameters to copy.</param>
      public ColumnSection(SectionDataBase sectionDataBase)
         : base(sectionDataBase)
      {
         Width = 0.0;
         Height = 0.0;
         Geometry = new Geometry();

         ListInternalForces = new List<InternalForcesBase>();
         MinStiffness = 0.0;
      }
   }
}
